# Two-Month Cohort Simulation

Generated: 2026-04-07T09:54:39.824Z
Window: 2026-01-05 to 2026-03-01

## Topline

- Leah: 97% adherence
- Nora: 92% adherence
- Mika: 91% adherence
- Jonah: 89% adherence
- Iris: 81% adherence

## Weekly Drift

- Nora: full_body 3 -> full_body 3, conservative weeks 0, build weeks 5, active replan weeks 2
- Mika: upper_lower 4 -> full_body 3, conservative weeks 2, build weeks 5, active replan weeks 2
- Iris: full_body 3 -> full_body 3, conservative weeks 1, build weeks 4, active replan weeks 4
- Jonah: full_body 3 -> upper_lower 4, conservative weeks 1, build weeks 4, active replan weeks 3
- Leah: upper_lower 4 -> upper_lower 4, conservative weeks 0, build weeks 6, active replan weeks 1

## Persona Readouts

### Nora

- Goal: build_consistency
- Experience: beginner
- Adherence: 92% (22/24 planned sessions completed)
- Session mix: modified 20, normal 3, conservative 1
- Progression intents: repeat 10, build 8, conservative 6
- Progression cues: hold_back 36, repeat 19, progress 8
- Top progression lifts: Barbell Bench Press:hold_back 18, Leg Press:hold_back 9, Calf Raise:hold_back 9, Leg Press:progress 8
- Recent lift trends: Leg Press:workable 42, Squat:workable 42, Barbell Back Squat:workable 29, Barbell Bench Press:strong 10
- Execution alignment: followed_planned 22
- Suggested-day drift: none
- Weekly review states: protecting 44, steady 12
- Weekly adaptation actions: protect_next_week 44, hold_next_week 12
- Outcome sizes: thin 13, partial 9
- Execution quality: workable 19, strong 3
- Slot coverage: main 100% / support 41%
- Weekly drift: full_body 3 -> full_body 3
- Weekly progression drift: hold_back 6 -> hold_back 6
- Weekly exercise drift: Barbell Bench Press hold_back 3, Leg Press hold_back 3 -> Barbell Bench Press hold_back 3, Leg Press hold_back 3
- Weekly recent-lift drift: none -> Leg Press workable 7 planned, Squat workable 7 planned, Barbell Back Squat workable 4 planned
- Weekly insight themes: Weekly state: steady 8, An alternating pattern is starting to hold 7, Logged day types and performed work are drifting apart 6, Leg Press is staying in the mix 4, Full body days are holding up well 3, Barbell Back Squat is staying in the mix 2, Barbell Bench Press is repeating well 1
- Active replan days: 8
- Read: Strong overall. The coach is keeping the plan productive without overcollapsing sessions.

### Mika

- Goal: build_muscle
- Experience: intermediate
- Adherence: 91% (31/34 planned sessions completed)
- Session mix: normal 17, modified 15, conservative 1, accessory_only 1
- Progression intents: build 12, conservative 11, repeat 11
- Progression cues: repeat 44, hold_back 36, progress 18
- Top progression lifts: Chest-Supported Machine Row:hold_back 8, Lat Pulldown:hold_back 8, Leg Curl:hold_back 8, Leg Press:hold_back 8
- Recent lift trends: Leg Press:strong 19, Barbell Bench Press:strong 18, Incline Dumbbell Press:strong 15, Lateral Raise:strong 14
- Execution alignment: followed_planned 28, no_explicit_alignment 3
- Suggested-day drift: none
- Weekly review states: protecting 32, steady 16, resetting 5, building 3
- Weekly adaptation actions: protect_next_week 32, hold_next_week 16, reset_next_week 5, build_next_week 3
- Outcome sizes: full 17, partial 12, thin 2
- Execution quality: strong 16, workable 12, survival 3
- Slot coverage: main 90% / support 87%
- Weekly drift: upper_lower 4 -> full_body 3
- Weekly progression drift: hold_back 8 -> hold_back 8
- Weekly exercise drift: Chest-Supported Machine Row hold_back 2, Lat Pulldown hold_back 2, Leg Curl hold_back 2 -> Chest-Supported Machine Row hold_back 2, Lat Pulldown hold_back 2, Leg Curl hold_back 2
- Weekly recent-lift drift: none -> Leg Press workable 4 planned, Assisted Pull-up (Machine) workable 2 planned, Chest-Supported Machine Row workable 2 planned
- Weekly insight themes: Weekly state: steady 8, Lower body days are holding up well 3, A stable split pattern is showing up 3, Pull day days need more protection 3, An alternating pattern is starting to hold 2, Leg Press is repeating well 2, Calf Raise is repeating well 1, Barbell Bench Press is repeating well 1, Assisted Pull-up (Machine) is repeating well 1, Rear Delt Fly is staying in the mix 1, Logged day types and performed work are drifting apart 1, Leg Press is staying in the mix 1
- Active replan days: 11
- Read: Strong overall. The coach is keeping the plan productive without overcollapsing sessions.

### Iris

- Goal: get_fitter
- Experience: intermediate
- Adherence: 81% (17/21 planned sessions completed)
- Session mix: modified 11, conservative 6, normal 4
- Progression intents: conservative 11, repeat 6, build 4
- Progression cues: hold_back 36, repeat 10, progress 2
- Top progression lifts: Barbell Bench Press:hold_back 18, Leg Press:hold_back 15, Leg Press:repeat 4, Barbell Bench Press:repeat 3
- Recent lift trends: Leg Press:workable 33, Squat:workable 33, Barbell Bench Press:workable 31, Barbell Back Squat:strong 8
- Execution alignment: followed_planned 17
- Suggested-day drift: none
- Weekly review states: protecting 38, steady 18
- Weekly adaptation actions: protect_next_week 38, hold_next_week 18
- Outcome sizes: partial 13, thin 4
- Execution quality: workable 14, strong 3
- Slot coverage: main 100% / support 76%
- Weekly drift: full_body 3 -> full_body 3
- Weekly progression drift: hold_back 6 -> hold_back 6, repeat 2, progress 1
- Weekly exercise drift: Barbell Bench Press hold_back 3, Leg Press hold_back 3 -> Barbell Bench Press hold_back 3, Calf Raise hold_back 3, Leg Press repeat 2
- Weekly recent-lift drift: none -> Leg Press workable 6 planned, Squat workable 6 planned, Barbell Bench Press workable 4 planned
- Weekly insight themes: Weekly state: steady 8, An alternating pattern is starting to hold 7, Barbell Bench Press is staying in the mix 6, Full body days need more protection 3, Full body days are holding up well 1, Logged day types and performed work are drifting apart 1, Leg Press is staying in the mix 1
- Active replan days: 14
- Read: Mostly believable, but still modification-heavy. Good candidate for future progression or recovery tuning.

### Jonah

- Goal: build_muscle
- Experience: intermediate
- Adherence: 89% (24/27 planned sessions completed)
- Session mix: conservative 14, modified 8, normal 5
- Progression intents: conservative 23, repeat 4
- Progression cues: hold_back 48, repeat 12
- Top progression lifts: Lat Pulldown:hold_back 34, Lat Pulldown:repeat 9, Leg Curl:hold_back 7, Leg Press:hold_back 7
- Recent lift trends: Chest-Supported Machine Row:workable 34, Lat Pulldown:workable 34, Leg Press:workable 27, Leg Curl:workable 8
- Execution alignment: followed_planned 23, used_substitutions 6, no_explicit_alignment 1
- Suggested-day drift: none
- Weekly review states: protecting 41, steady 11, building 4
- Weekly adaptation actions: protect_next_week 41, hold_next_week 11, build_next_week 4
- Outcome sizes: thin 12, partial 6, full 6
- Execution quality: workable 21, strong 3
- Slot coverage: main 100% / support 33%
- Weekly drift: full_body 3 -> upper_lower 4
- Weekly progression drift: hold_back 6 -> hold_back 6, repeat 3
- Weekly exercise drift: Lat Pulldown hold_back 6 -> Lat Pulldown repeat 3, Lat Pulldown hold_back 2, Leg Curl hold_back 2
- Weekly recent-lift drift: none -> Leg Press workable 5 planned, Chest-Supported Machine Row workable 4 planned, Lat Pulldown workable 4 planned
- Weekly insight themes: Weekly state: steady 8, Chest-Supported Machine Row is staying in the mix 5, An alternating pattern is starting to hold 4, Logged day types and performed work are drifting apart 4, Lower body days are holding up well 3, Full body days are holding up well 2, A stable split pattern is showing up 2, Leg Press is staying in the mix 2
- Active replan days: 11
- Read: Mostly believable, but still modification-heavy. Good candidate for future progression or recovery tuning.

### Leah

- Goal: build_muscle
- Experience: intermediate
- Adherence: 97% (30/31 planned sessions completed)
- Session mix: normal 15, modified 15, conservative 1
- Progression intents: build 16, repeat 12, conservative 3
- Progression cues: hold_back 34, repeat 34, progress 18
- Top progression lifts: Leg Press:repeat 19, Leg Press:hold_back 18, Chest-Supported Machine Row:hold_back 16, Chest-Supported Machine Row:repeat 15
- Recent lift trends: Leg Press:strong 21, Barbell Bench Press:workable 20, Chest-Supported Machine Row:workable 19, Lat Pulldown:workable 18
- Execution alignment: followed_planned 26, no_explicit_alignment 4, used_substitutions 2
- Suggested-day drift: none
- Weekly review states: protecting 42, steady 8, building 6
- Weekly adaptation actions: protect_next_week 42, hold_next_week 8, build_next_week 6
- Outcome sizes: thin 12, partial 10, full 8
- Execution quality: workable 18, strong 11, survival 1
- Slot coverage: main 97% / support 40%
- Weekly drift: upper_lower 4 -> upper_lower 4
- Weekly progression drift: hold_back 8 -> hold_back 6
- Weekly exercise drift: Chest-Supported Machine Row hold_back 4, Leg Press hold_back 4 -> Leg Press hold_back 6
- Weekly recent-lift drift: none -> Chest-Supported Machine Row workable 4 planned, Leg Press workable 4 planned, Barbell Bench Press workable 3 planned
- Weekly insight themes: Weekly state: steady 8, A stable split pattern is showing up 5, Upper body days are holding up well 4, Lower body days are holding up well 3, Barbell Bench Press is staying in the mix 2, Calf Raise is repeating well 1, An alternating pattern is starting to hold 1, Leg Press is repeating well 1, Barbell Back Squat is repeating well 1, Barbell Bench Press is repeating well 1, Chest-Supported Machine Row is staying in the mix 1
- Active replan days: 5
- Read: Strong overall. The coach is keeping the plan productive without overcollapsing sessions.

## Quick Calls

- Nora looks production-promising for this persona.
- Mika looks production-promising for this persona.
- Iris is stable but still modification-heavy, so future tuning should focus on keeping more days normal.
- Jonah is stable but still modification-heavy, so future tuning should focus on keeping more days normal.
- Leah looks production-promising for this persona.


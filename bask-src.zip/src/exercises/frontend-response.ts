import { getExerciseLibrary } from "./library.js";
import { describeConservativeSessionHeadline } from "../kai/coaching-copy.js";
import type {
  FrontendExerciseDecisionRationale,
  FrontendReadinessCopy,
  FrontendReadinessDecisionAudit,
  FrontendReadinessExplanation,
  FrontendWeeklyPlanContext,
  FrontendTrainingReadinessResponse,
  MovementPattern,
  ReadinessHistoryEntry,
  TrainingReadinessReport
} from "./types.js";

export function buildFrontendTrainingReadinessResponse(
  userId: string,
  asOf: string,
  trainingReadiness: TrainingReadinessReport,
  weeklyPlanContext?: FrontendWeeklyPlanContext
): FrontendTrainingReadinessResponse {
  const primaryExerciseNames = resolvePrimaryExerciseNames(trainingReadiness);
  const frontendCopy = buildFrontendReadinessCopy(
    trainingReadiness,
    weeklyPlanContext,
    primaryExerciseNames
  );
  const frontendExplanation = buildFrontendReadinessExplanation(
    trainingReadiness,
    primaryExerciseNames,
    weeklyPlanContext
  );
  const saferAlternatives = trimFrontendSafeAlternatives(trainingReadiness);
  const recoveringMuscles = trainingReadiness.muscleLoadSummary
    .filter((entry) => entry.recoveryState === "recovering")
    .map((entry) => entry.muscle);
  const decisionAudit = buildFrontendReadinessDecisionAudit(
    trainingReadiness,
    frontendCopy,
    frontendExplanation,
    saferAlternatives,
    recoveringMuscles
  );

  return {
    userId,
    asOf,
    plannedWorkoutType: trainingReadiness.plannedWorkoutType,
    frontendCopy,
    frontendExplanation,
    decisionAudit,
    weeklyPlanContext,
    readinessModel: trainingReadiness.readinessModel,
    sessionDecision: trainingReadiness.sessionDecision,
    sessionPlan: trainingReadiness.sessionPlan,
    substitutionOptions: trainingReadiness.substitutionOptions,
    muscleLoadSummary: trainingReadiness.muscleLoadSummary,
    overworkedMuscles: trainingReadiness.overworkedMuscles,
    recoveringMuscles,
    muscleGroupsToAvoidToday: trainingReadiness.recommendedMusclesToAvoid,
    exercisesToAvoidToday: trainingReadiness.avoidExercises,
    saferAlternatives,
    deprioritizedExercises: trainingReadiness.deprioritizedExercises
  };
}

export function buildFrontendReadinessCopy(
  trainingReadiness: TrainingReadinessReport,
  weeklyPlanContext?: FrontendWeeklyPlanContext,
  primaryExerciseNames = resolvePrimaryExerciseNames(trainingReadiness)
): FrontendReadinessCopy {
  const primaryBlock = trainingReadiness.sessionPlan.blocks.find(
    (block) => (block.exampleExercises?.length ?? block.exampleExerciseIds.length) > 0
  );

  return {
    sessionLabel: toSessionLabel(trainingReadiness.sessionPlan.sessionStyle),
    readinessHeadline: toReadinessHeadline(trainingReadiness, weeklyPlanContext),
    primaryAction: toPrimaryAction(
      trainingReadiness,
      primaryBlock?.blockTier,
      primaryExerciseNames
    ),
    fallbackNote: toFallbackNote(primaryBlock?.blockTier, primaryExerciseNames)
  };
}

export function buildFrontendReadinessExplanation(
  trainingReadiness: TrainingReadinessReport,
  primaryExerciseNames = resolvePrimaryExerciseNames(trainingReadiness),
  weeklyPlanContext?: FrontendWeeklyPlanContext
): FrontendReadinessExplanation {
  const weekContext = toWeekContext(weeklyPlanContext);

  return {
    planWhy: trainingReadiness.sessionPlan.objective,
    whatChangedToday: toWhatChangedToday(trainingReadiness),
    ...(weekContext ? { weekContext } : {}),
    whyTodayLooksThisWay: collectWhyTodayLooksThisWay(trainingReadiness),
    focusAreas: collectFocusAreas(trainingReadiness),
    cautionAreas: collectCautionAreas(trainingReadiness),
    startingExercises: primaryExerciseNames
  };
}

export function buildReadinessHistoryEntry(
  response: FrontendTrainingReadinessResponse,
  recordedAt = new Date().toISOString()
): ReadinessHistoryEntry {
  return {
    userId: response.userId,
    asOf: response.asOf,
    recordedAt,
    plannedWorkoutType: response.plannedWorkoutType,
    sessionStyle: response.sessionPlan.sessionStyle,
    sessionDecisionStatus: response.sessionDecision.status,
    readinessScore: response.readinessModel.score,
    readinessBand: response.readinessModel.band,
    dataConfidence: response.readinessModel.dataConfidence,
    frontendCopy: response.frontendCopy,
    frontendExplanation: response.frontendExplanation,
    focusMuscles: response.sessionPlan.focusMuscles,
    limitMuscles: response.sessionPlan.limitMuscles,
    overworkedMuscles: response.overworkedMuscles,
    recoveringMuscles: response.recoveringMuscles,
    muscleGroupsToAvoidToday: response.muscleGroupsToAvoidToday,
    primaryExerciseIds: resolvePrimaryExerciseIds(response.sessionPlan)
  };
}

function toSessionLabel(
  sessionStyle: "normal" | "conservative" | "modified" | "accessory_only"
): string {
  if (sessionStyle === "accessory_only") {
    return "Accessory-only session";
  }

  if (sessionStyle === "conservative") {
    return "Conservative session";
  }

  if (sessionStyle === "modified") {
    return "Modified session";
  }

  return "Normal session";
}

function toReadinessHeadline(
  trainingReadiness: TrainingReadinessReport,
  weeklyPlanContext?: FrontendWeeklyPlanContext
): string {
  const arcContext = toHeadlineArcContext(weeklyPlanContext);
  const workoutTypeContext =
    weeklyPlanContext?.fragileWorkoutTypeLabel &&
    trainingReadiness.plannedWorkoutType &&
    weeklyPlanContext.fragileWorkoutTypeLabel.toLowerCase().replaceAll(" ", "_") ===
      trainingReadiness.plannedWorkoutType
      ? ` ${weeklyPlanContext.fragileWorkoutTypeLabel} work has been the least stable part of the week.`
      : "";
  const suggestedDriftContext =
    !weeklyPlanContext?.todayPlanned &&
    weeklyPlanContext?.suggestedWorkoutDriftLabel &&
    weeklyPlanContext?.suggestedWorkoutTypeLabel
      ? ` Recent ${weeklyPlanContext.suggestedWorkoutTypeLabel.toLowerCase()} suggestions have often turned into ${weeklyPlanContext.suggestedWorkoutDriftLabel.toLowerCase()} work instead.`
      : "";

  if (trainingReadiness.sessionPlan.sessionStyle === "accessory_only") {
    return `Keep the day, but keep it very small.${arcContext}${workoutTypeContext}${suggestedDriftContext}`;
  }

  if (trainingReadiness.sessionPlan.sessionStyle === "conservative") {
    return `${describeConservativeSessionHeadline()}${arcContext}${workoutTypeContext}${suggestedDriftContext}`;
  }

  if (trainingReadiness.sessionDecision.status === "train_modified") {
    return `Train, but keep the overlap under control.${arcContext}${workoutTypeContext}${suggestedDriftContext}`;
  }

  if (trainingReadiness.sessionDecision.status === "train_light") {
    return `Keep today light and easy to recover from.${arcContext}${workoutTypeContext}${suggestedDriftContext}`;
  }

  return `Train as planned.${arcContext}${suggestedDriftContext}`;
}

function toPrimaryAction(
  trainingReadiness: TrainingReadinessReport,
  blockTier: "best" | "acceptable" | undefined,
  exerciseNames: string[]
): string {
  if (!exerciseNames.length) {
    return trainingReadiness.sessionPlan.coachNote ?? trainingReadiness.sessionDecision.summary;
  }

  const formattedNames = formatNameList(exerciseNames);

  if (blockTier === "best") {
    return `Start with ${formattedNames}. That is your best fit today.`;
  }

  if (blockTier === "acceptable") {
    return `Use ${formattedNames} as an acceptable fallback today.`;
  }

  return `Start with ${formattedNames}.`;
}

function toFallbackNote(
  blockTier: "best" | "acceptable" | undefined,
  exerciseNames: string[]
): string | undefined {
  if (!exerciseNames.length) {
    return undefined;
  }

  if (blockTier === "best") {
    return "This is the cleanest option the backend sees for today.";
  }

  if (blockTier === "acceptable") {
    return "This works today, but it is more fallback than ideal.";
  }

  return undefined;
}

function formatNameList(names: string[]): string {
  if (names.length === 1) {
    return names[0].toLowerCase();
  }

  return `${names[0].toLowerCase()} or ${names[1].toLowerCase()}`;
}

function resolvePrimaryExerciseNames(trainingReadiness: TrainingReadinessReport): string[] {
  const primaryExamples = resolvePrimaryExerciseIds(trainingReadiness.sessionPlan);

  return primaryExamples
    .map((exerciseId) => getExerciseName(exerciseId))
    .filter((name): name is string => Boolean(name));
}

function resolvePrimaryExerciseIds(
  sessionPlan: TrainingReadinessReport["sessionPlan"]
): string[] {
  const primaryBlock = sessionPlan.blocks.find(
    (block) => (block.exampleExercises?.length ?? block.exampleExerciseIds.length) > 0
  );

  return (
    primaryBlock?.exampleExercises?.map((example) => example.exerciseId) ??
    primaryBlock?.exampleExerciseIds ??
    []
  );
}

function collectWhyTodayLooksThisWay(trainingReadiness: TrainingReadinessReport): string[] {
  const reasons = dedupeStrings([
    ...trainingReadiness.sessionDecision.notes,
    ...trainingReadiness.readinessModel.reasons
  ]).slice(0, 4);

  if (reasons.length) {
    return reasons;
  }

  return [trainingReadiness.sessionDecision.summary];
}

function toHeadlineArcContext(
  weeklyPlanContext?: FrontendWeeklyPlanContext
): string {
  switch (weeklyPlanContext?.weeklyArcPattern) {
    case "rebuilding":
      return " You are climbing back up, so keep today repeatable.";
    case "building":
      return " The last few weeks are stacking well, so protect that momentum.";
    case "protecting":
      return " Recent weeks have needed more protection, so keep the session manageable.";
    case "oscillating":
      return " The last few weeks have been up and down, so keep today steady.";
    case "steady":
      return " You are building a steadier base, so keep the rhythm clean.";
    case "starting":
      return " A longer pattern is just starting to form, so keep the day simple.";
    default:
      return "";
  }
}

function toWeekContext(
  weeklyPlanContext?: FrontendWeeklyPlanContext
): string | undefined {
  const baseContext = (() => {
    switch (weeklyPlanContext?.weeklyArcPattern) {
      case "rebuilding":
        return "This day sits inside a rebuild stretch, so the goal is to keep progress feeling repeatable.";
      case "building":
        return "This day sits inside a stronger run of weeks, so the goal is to keep the momentum clean.";
      case "protecting":
        return "This day sits inside a more protective stretch, so the goal is to finish it without digging a bigger hole.";
      case "oscillating":
        return "This day sits inside an up-and-down stretch, so the goal is to make the pattern feel steadier.";
      case "steady":
        return "This day sits inside a steadier stretch, so the goal is to keep the routine consistent.";
      case "starting":
        return "This day is part of an early pattern, so the goal is to make it easy to repeat.";
      default:
        return undefined;
    }
  })();

  if (weeklyPlanContext?.suggestedWorkoutTemplateNote) {
    return [baseContext, weeklyPlanContext.suggestedWorkoutTemplateNote]
      .filter(Boolean)
      .join(" ");
  }

  return baseContext;
}

function trimFrontendSafeAlternatives(
  trainingReadiness: TrainingReadinessReport
): TrainingReadinessReport["recommendedExercises"] {
  const recommendedById = new Map(
    trainingReadiness.recommendedExercises.map((entry) => [entry.exerciseId, entry])
  );
  const orderedExerciseIds: string[] = [];

  for (const block of trainingReadiness.sessionPlan.blocks) {
    const blockIds =
      block.exampleExercises?.map((example) => example.exerciseId) ??
      block.exampleExerciseIds ??
      [];

    for (const exerciseId of blockIds) {
      if (recommendedById.has(exerciseId) && !orderedExerciseIds.includes(exerciseId)) {
        orderedExerciseIds.push(exerciseId);
      }
    }
  }

  for (const entry of trainingReadiness.recommendedExercises) {
    if (!orderedExerciseIds.includes(entry.exerciseId)) {
      orderedExerciseIds.push(entry.exerciseId);
    }
  }

  return orderedExerciseIds
    .map((exerciseId) => recommendedById.get(exerciseId))
    .filter(
      (
        entry
      ): entry is TrainingReadinessReport["recommendedExercises"][number] => Boolean(entry)
    )
    .slice(0, 8);
}

function buildFrontendReadinessDecisionAudit(
  trainingReadiness: TrainingReadinessReport,
  frontendCopy: FrontendReadinessCopy,
  frontendExplanation: FrontendReadinessExplanation,
  saferAlternatives: TrainingReadinessReport["recommendedExercises"],
  recoveringMuscles: FrontendTrainingReadinessResponse["recoveringMuscles"]
): FrontendReadinessDecisionAudit {
  const recoveredMuscles = trainingReadiness.muscleLoadSummary
    .filter((entry) => entry.recoveryState === "recovered")
    .map((entry) => entry.muscle)
    .slice(0, 8);
  const avoidMovementPatterns = dedupeMovementPatterns([
    ...trainingReadiness.sessionPlan.limitPatterns,
    ...trainingReadiness.overworkedPatterns
  ]).slice(0, 4);
  const deprioritizedExercises = toExerciseDecisionRationales(
    trainingReadiness.deprioritizedExercises,
    4
  );
  const selectedSubstitutes = toExerciseDecisionRationales(saferAlternatives, 4);

  return {
    recommendedTrainingDirection: trainingReadiness.sessionPlan.objective,
    recoveredMuscles,
    recoveringMuscles,
    avoidMuscles: trainingReadiness.recommendedMusclesToAvoid.slice(0, 6),
    avoidMovementPatterns,
    deprioritizedExercises,
    selectedSubstitutes,
    userExplanation: buildUserFacingDecisionExplanation(
      trainingReadiness,
      frontendCopy,
      recoveringMuscles,
      trainingReadiness.recommendedMusclesToAvoid,
      avoidMovementPatterns
    ),
    kaiExplanation: buildKaiFriendlyDecisionExplanation(
      trainingReadiness,
      frontendExplanation,
      recoveringMuscles,
      trainingReadiness.recommendedMusclesToAvoid,
      avoidMovementPatterns
    ),
    debugExplanation: buildDebugDecisionExplanation(
      trainingReadiness,
      deprioritizedExercises,
      selectedSubstitutes,
      avoidMovementPatterns
    )
  };
}

function collectFocusAreas(trainingReadiness: TrainingReadinessReport): string[] {
  const blockFocus = dedupeStrings(
    trainingReadiness.sessionPlan.blocks
      .filter((block) => (block.exampleExercises?.length ?? block.exampleExerciseIds.length) > 0)
      .map((block) => block.focus)
  ).slice(0, 3);

  if (blockFocus.length) {
    return blockFocus;
  }

  return trainingReadiness.sessionPlan.focusMuscles.slice(0, 3).map(formatMuscleLabel);
}

function collectCautionAreas(trainingReadiness: TrainingReadinessReport): string[] {
  const cautions: string[] = [];

  if (trainingReadiness.sessionPlan.limitMuscles.length) {
    cautions.push(
      `Limit overlap on ${formatLabelList(
        trainingReadiness.sessionPlan.limitMuscles.slice(0, 3).map(formatMuscleLabel)
      )}.`
    );
  } else if (trainingReadiness.overworkedMuscles.length) {
    cautions.push(
      `Watch ${formatLabelList(
        trainingReadiness.overworkedMuscles.slice(0, 3).map(formatMuscleLabel)
      )} closely today.`
    );
  }

  if (trainingReadiness.sessionPlan.limitPatterns.length) {
    cautions.push(
      `Keep ${formatLabelList(
        trainingReadiness.sessionPlan.limitPatterns.slice(0, 2).map(formatMovementPatternLabel)
      )} loading lighter today.`
    );
  }

  if (trainingReadiness.avoidExercises[0]) {
    const topAvoidReason = trainingReadiness.avoidExercises[0].reasons[0];

    cautions.push(
      topAvoidReason?.startsWith("Equipment mismatch:")
        ? topAvoidReason
        : `Avoid ${trainingReadiness.avoidExercises[0].name} today.`
    );
  }

  return dedupeStrings(cautions).slice(0, 3);
}

function toWhatChangedToday(trainingReadiness: TrainingReadinessReport): string | undefined {
  if (trainingReadiness.sessionPlan.sessionStyle === "accessory_only") {
    return "The original day stayed in place, but it was reduced to small fallback work.";
  }

  if (trainingReadiness.sessionPlan.sessionStyle === "conservative") {
    return "The session stayed on the calendar, but the backend cooled the volume and intensity.";
  }

  if (trainingReadiness.sessionDecision.status === "train_modified") {
    return "The day stayed in place, but the backend shifted the work away from the main recovery bottlenecks.";
  }

  if (trainingReadiness.sessionDecision.status === "train_light") {
    return "The session was kept intentionally light so recovery can catch back up.";
  }

  return undefined;
}

function getExerciseName(exerciseId: string): string | undefined {
  return getExerciseLibrary().find((exercise) => exercise.exerciseId === exerciseId)?.name;
}

function toExerciseDecisionRationales(
  exercises: TrainingReadinessReport["recommendedExercises"] | TrainingReadinessReport["deprioritizedExercises"],
  limit: number
): FrontendExerciseDecisionRationale[] {
  return exercises.slice(0, limit).map((entry) => ({
    exerciseId: entry.exerciseId,
    name: entry.name,
    why: entry.reasons.slice(0, 3)
  }));
}

function buildUserFacingDecisionExplanation(
  trainingReadiness: TrainingReadinessReport,
  frontendCopy: FrontendReadinessCopy,
  recoveringMuscles: string[],
  avoidMuscles: string[],
  avoidMovementPatterns: MovementPattern[]
): string {
  const whySentence = frontendCopy.primaryAction.endsWith(".")
    ? frontendCopy.primaryAction
    : `${frontendCopy.primaryAction}.`;
  const cautionLabels = [
    ...avoidMuscles.slice(0, 3).map(formatMuscleLabel),
    ...avoidMovementPatterns.slice(0, 2).map(formatMovementPatternLabel)
  ];
  const cautionSentence = cautionLabels.length
    ? `Keep overlap away from ${formatLabelList(cautionLabels)} today.`
    : recoveringMuscles.length
      ? `Keep overlap away from ${formatLabelList(
          recoveringMuscles.slice(0, 3).map(formatMuscleLabel)
        )} today.`
      : undefined;

  return [frontendCopy.readinessHeadline, whySentence, cautionSentence]
    .filter(Boolean)
    .join(" ");
}

function buildKaiFriendlyDecisionExplanation(
  trainingReadiness: TrainingReadinessReport,
  frontendExplanation: FrontendReadinessExplanation,
  recoveringMuscles: string[],
  avoidMuscles: string[],
  avoidMovementPatterns: MovementPattern[]
): string {
  const focus = frontendExplanation.focusAreas[0]?.toLowerCase();
  const topLimiter =
    avoidMuscles[0] ?? recoveringMuscles[0] ?? trainingReadiness.overworkedMuscles[0];
  const patternLimiter = avoidMovementPatterns[0];
  const limiterParts = [
    topLimiter ? `limiter ${formatMuscleLabel(topLimiter)}` : undefined,
    patternLimiter ? `pattern ${formatMovementPatternLabel(patternLimiter)}` : undefined
  ].filter(Boolean);

  return [
    `${trainingReadiness.sessionDecision.sessionMode}: ${trainingReadiness.sessionPlan.objective}`,
    focus ? `focus ${focus}` : undefined,
    limiterParts.length ? limiterParts.join(", ") : undefined
  ]
    .filter(Boolean)
    .join(" | ");
}

function buildDebugDecisionExplanation(
  trainingReadiness: TrainingReadinessReport,
  deprioritizedExercises: FrontendExerciseDecisionRationale[],
  selectedSubstitutes: FrontendExerciseDecisionRationale[],
  avoidMovementPatterns: MovementPattern[]
): FrontendReadinessDecisionAudit["debugExplanation"] {
  const topRecoveryLimiters = trainingReadiness.muscleLoadSummary
    .filter((entry) => entry.recoveryState !== "recovered")
    .slice(0, 3)
    .map((entry) => `${formatMuscleLabel(entry.muscle)} (${entry.recoveryState})`);
  const recommendationNotes = dedupeStrings([
    ...trainingReadiness.sessionDecision.notes,
    ...trainingReadiness.readinessModel.reasons,
    ...selectedSubstitutes.flatMap((entry) => entry.why.slice(0, 1)),
    ...deprioritizedExercises.flatMap((entry) => entry.why.slice(0, 1))
  ]).slice(0, 6);

  return {
    decisionSummary: `${trainingReadiness.sessionDecision.status} | ${trainingReadiness.sessionPlan.sessionStyle} | ${trainingReadiness.readinessModel.band} ${trainingReadiness.readinessModel.score.toFixed(0)}`,
    topRecoveryLimiters,
    topAvoidedPatterns: avoidMovementPatterns.map(formatMovementPatternLabel),
    recommendationNotes
  };
}

function formatMuscleLabel(muscle: string): string {
  return muscle.replaceAll("_", " ");
}

function formatMovementPatternLabel(movementPattern: MovementPattern): string {
  return movementPattern.replaceAll("_", " ");
}

function formatLabelList(labels: string[]): string {
  if (labels.length <= 1) {
    return labels[0] ?? "";
  }

  if (labels.length === 2) {
    return `${labels[0]} and ${labels[1]}`;
  }

  return `${labels[0]}, ${labels[1]}, and ${labels[2]}`;
}

function dedupeStrings(items: string[]): string[] {
  const seen = new Set<string>();

  return items.filter((item) => {
    const normalized = item.trim().toLowerCase();

    if (!normalized || seen.has(normalized)) {
      return false;
    }

    seen.add(normalized);
    return true;
  });
}

function dedupeMovementPatterns(items: MovementPattern[]): MovementPattern[] {
  const seen = new Set<MovementPattern>();

  return items.filter((item) => {
    if (seen.has(item)) {
      return false;
    }

    seen.add(item);
    return true;
  });
}
